﻿namespace Proyecto_Topicos
{
    partial class CU_Bebidas
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBorrar = new System.Windows.Forms.Button();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.txtTotal2 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbcafe = new System.Windows.Forms.ComboBox();
            this.cbte = new System.Windows.Forms.ComboBox();
            this.cbice = new System.Windows.Forms.ComboBox();
            this.cbjugo = new System.Windows.Forms.ComboBox();
            this.cbpepino = new System.Windows.Forms.ComboBox();
            this.Cblimon = new System.Windows.Forms.ComboBox();
            this.Cbagua = new System.Windows.Forms.ComboBox();
            this.CbSoda = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Vegana = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Cafe = new System.Windows.Forms.CheckBox();
            this.Pepino = new System.Windows.Forms.CheckBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.Te = new System.Windows.Forms.CheckBox();
            this.Ice = new System.Windows.Forms.CheckBox();
            this.KidJugo = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lblawa = new System.Windows.Forms.Label();
            this.Limonada = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Soda = new System.Windows.Forms.CheckBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.Agua = new System.Windows.Forms.CheckBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lblsoda = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.groupBox5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.SuspendLayout();
            // 
            // btnBorrar
            // 
            this.btnBorrar.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBorrar.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBorrar.Location = new System.Drawing.Point(1194, 580);
            this.btnBorrar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnBorrar.Name = "btnBorrar";
            this.btnBorrar.Size = new System.Drawing.Size(246, 50);
            this.btnBorrar.TabIndex = 30;
            this.btnBorrar.Text = "Borrar";
            this.btnBorrar.UseVisualStyleBackColor = false;
            this.btnBorrar.Click += new System.EventHandler(this.btnBorrar_Click);
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnCalcular.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(1194, 511);
            this.btnCalcular.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(246, 47);
            this.btnCalcular.TabIndex = 29;
            this.btnCalcular.Text = "Calcular orden";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.LavenderBlush;
            this.groupBox5.Controls.Add(this.label2);
            this.groupBox5.Controls.Add(this.label);
            this.groupBox5.Controls.Add(this.txtTotal2);
            this.groupBox5.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(1147, 371);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox5.Size = new System.Drawing.Size(339, 109);
            this.groupBox5.TabIndex = 26;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Total";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(78, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(25, 27);
            this.label2.TabIndex = 2;
            this.label2.Text = "$";
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.Location = new System.Drawing.Point(227, 57);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(66, 27);
            this.label.TabIndex = 1;
            this.label.Text = "MXN";
            // 
            // txtTotal2
            // 
            this.txtTotal2.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotal2.Location = new System.Drawing.Point(109, 48);
            this.txtTotal2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTotal2.Name = "txtTotal2";
            this.txtTotal2.Size = new System.Drawing.Size(112, 36);
            this.txtTotal2.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.LavenderBlush;
            this.groupBox1.Controls.Add(this.cbcafe);
            this.groupBox1.Controls.Add(this.cbte);
            this.groupBox1.Controls.Add(this.cbice);
            this.groupBox1.Controls.Add(this.cbjugo);
            this.groupBox1.Controls.Add(this.cbpepino);
            this.groupBox1.Controls.Add(this.Cblimon);
            this.groupBox1.Controls.Add(this.Cbagua);
            this.groupBox1.Controls.Add(this.CbSoda);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.Vegana);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.Cafe);
            this.groupBox1.Controls.Add(this.Pepino);
            this.groupBox1.Controls.Add(this.pictureBox8);
            this.groupBox1.Controls.Add(this.pictureBox7);
            this.groupBox1.Controls.Add(this.pictureBox6);
            this.groupBox1.Controls.Add(this.pictureBox5);
            this.groupBox1.Controls.Add(this.pictureBox4);
            this.groupBox1.Controls.Add(this.Te);
            this.groupBox1.Controls.Add(this.Ice);
            this.groupBox1.Controls.Add(this.KidJugo);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.lblawa);
            this.groupBox1.Controls.Add(this.Limonada);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.Soda);
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.Agua);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.lblsoda);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(25, 15);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Size = new System.Drawing.Size(1106, 666);
            this.groupBox1.TabIndex = 27;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Bebidas";
            // 
            // cbcafe
            // 
            this.cbcafe.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbcafe.FormattingEnabled = true;
            this.cbcafe.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.cbcafe.Location = new System.Drawing.Point(979, 611);
            this.cbcafe.Name = "cbcafe";
            this.cbcafe.Size = new System.Drawing.Size(57, 31);
            this.cbcafe.TabIndex = 50;
            this.cbcafe.SelectedIndexChanged += new System.EventHandler(this.cbcafe_SelectedIndexChanged);
            // 
            // cbte
            // 
            this.cbte.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbte.FormattingEnabled = true;
            this.cbte.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.cbte.Location = new System.Drawing.Point(718, 621);
            this.cbte.Name = "cbte";
            this.cbte.Size = new System.Drawing.Size(67, 31);
            this.cbte.TabIndex = 49;
            this.cbte.SelectedIndexChanged += new System.EventHandler(this.cbte_SelectedIndexChanged);
            // 
            // cbice
            // 
            this.cbice.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbice.FormattingEnabled = true;
            this.cbice.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.cbice.Location = new System.Drawing.Point(443, 619);
            this.cbice.Name = "cbice";
            this.cbice.Size = new System.Drawing.Size(63, 31);
            this.cbice.TabIndex = 48;
            this.cbice.SelectedIndexChanged += new System.EventHandler(this.cbice_SelectedIndexChanged);
            // 
            // cbjugo
            // 
            this.cbjugo.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbjugo.FormattingEnabled = true;
            this.cbjugo.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.cbjugo.Location = new System.Drawing.Point(171, 619);
            this.cbjugo.Name = "cbjugo";
            this.cbjugo.Size = new System.Drawing.Size(64, 31);
            this.cbjugo.TabIndex = 47;
            this.cbjugo.SelectedIndexChanged += new System.EventHandler(this.cbjugo_SelectedIndexChanged);
            // 
            // cbpepino
            // 
            this.cbpepino.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbpepino.FormattingEnabled = true;
            this.cbpepino.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.cbpepino.Location = new System.Drawing.Point(979, 307);
            this.cbpepino.Name = "cbpepino";
            this.cbpepino.Size = new System.Drawing.Size(57, 31);
            this.cbpepino.TabIndex = 46;
            this.cbpepino.SelectedIndexChanged += new System.EventHandler(this.cbpepino_SelectedIndexChanged);
            // 
            // Cblimon
            // 
            this.Cblimon.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cblimon.FormattingEnabled = true;
            this.Cblimon.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.Cblimon.Location = new System.Drawing.Point(725, 303);
            this.Cblimon.Name = "Cblimon";
            this.Cblimon.Size = new System.Drawing.Size(69, 31);
            this.Cblimon.TabIndex = 45;
            this.Cblimon.SelectedIndexChanged += new System.EventHandler(this.Cblimon_SelectedIndexChanged);
            // 
            // Cbagua
            // 
            this.Cbagua.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cbagua.FormattingEnabled = true;
            this.Cbagua.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.Cbagua.Location = new System.Drawing.Point(443, 307);
            this.Cbagua.Name = "Cbagua";
            this.Cbagua.Size = new System.Drawing.Size(63, 31);
            this.Cbagua.TabIndex = 44;
            this.Cbagua.SelectedIndexChanged += new System.EventHandler(this.Cbagua_SelectedIndexChanged);
            // 
            // CbSoda
            // 
            this.CbSoda.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CbSoda.FormattingEnabled = true;
            this.CbSoda.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.CbSoda.Location = new System.Drawing.Point(174, 309);
            this.CbSoda.Name = "CbSoda";
            this.CbSoda.Size = new System.Drawing.Size(64, 31);
            this.CbSoda.TabIndex = 43;
            this.CbSoda.SelectedIndexChanged += new System.EventHandler(this.CbSoda_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(922, 347);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(79, 28);
            this.label11.TabIndex = 30;
            this.label11.Text = "CAFE";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(632, 347);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(153, 28);
            this.label10.TabIndex = 29;
            this.label10.Text = "TE HELADO";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(406, 358);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 28);
            this.label9.TabIndex = 28;
            this.label9.Text = "ICE";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(99, 356);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(126, 28);
            this.label8.TabIndex = 27;
            this.label8.Text = "Juguito";
            // 
            // Vegana
            // 
            this.Vegana.AutoSize = true;
            this.Vegana.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Vegana.Location = new System.Drawing.Point(844, 39);
            this.Vegana.Name = "Vegana";
            this.Vegana.Size = new System.Drawing.Size(239, 28);
            this.Vegana.TabIndex = 26;
            this.Vegana.Text = "Agua de pepino";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(628, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 28);
            this.label1.TabIndex = 25;
            this.label1.Text = "LIMONADA";
            // 
            // Cafe
            // 
            this.Cafe.AutoSize = true;
            this.Cafe.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cafe.Location = new System.Drawing.Point(891, 613);
            this.Cafe.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Cafe.Name = "Cafe";
            this.Cafe.Size = new System.Drawing.Size(92, 27);
            this.Cafe.TabIndex = 24;
            this.Cafe.Text = "$45.00";
            this.Cafe.UseVisualStyleBackColor = true;
            // 
            // Pepino
            // 
            this.Pepino.AutoSize = true;
            this.Pepino.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pepino.Location = new System.Drawing.Point(891, 309);
            this.Pepino.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Pepino.Name = "Pepino";
            this.Pepino.Size = new System.Drawing.Size(92, 27);
            this.Pepino.TabIndex = 23;
            this.Pepino.Text = "$20.00";
            this.Pepino.UseVisualStyleBackColor = true;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::Proyecto_Topicos.Properties.Resources._2_4_;
            this.pictureBox8.Location = new System.Drawing.Point(600, 379);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(214, 216);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 22;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Proyecto_Topicos.Properties.Resources.xdxdxd;
            this.pictureBox7.Location = new System.Drawing.Point(322, 388);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(216, 216);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 21;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Proyecto_Topicos.Properties.Resources._5_3_;
            this.pictureBox6.Location = new System.Drawing.Point(44, 388);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(224, 216);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 20;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Proyecto_Topicos.Properties.Resources._8_2_;
            this.pictureBox5.Location = new System.Drawing.Point(849, 379);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(222, 216);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 19;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Proyecto_Topicos.Properties.Resources._4_3_;
            this.pictureBox4.Location = new System.Drawing.Point(849, 71);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(222, 221);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 18;
            this.pictureBox4.TabStop = false;
            // 
            // Te
            // 
            this.Te.AutoSize = true;
            this.Te.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Te.Location = new System.Drawing.Point(620, 624);
            this.Te.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Te.Name = "Te";
            this.Te.Size = new System.Drawing.Size(92, 27);
            this.Te.TabIndex = 17;
            this.Te.Text = "$25.00";
            this.Te.UseVisualStyleBackColor = true;
            // 
            // Ice
            // 
            this.Ice.AutoSize = true;
            this.Ice.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ice.Location = new System.Drawing.Point(345, 623);
            this.Ice.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Ice.Name = "Ice";
            this.Ice.Size = new System.Drawing.Size(92, 27);
            this.Ice.TabIndex = 16;
            this.Ice.Text = "$35.00";
            this.Ice.UseVisualStyleBackColor = true;
            // 
            // KidJugo
            // 
            this.KidJugo.AutoSize = true;
            this.KidJugo.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KidJugo.Location = new System.Drawing.Point(73, 623);
            this.KidJugo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.KidJugo.Name = "KidJugo";
            this.KidJugo.Size = new System.Drawing.Size(92, 27);
            this.KidJugo.TabIndex = 15;
            this.KidJugo.Text = "$15.00";
            this.KidJugo.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(463, 52);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 28);
            this.label7.TabIndex = 14;
            // 
            // lblawa
            // 
            this.lblawa.AutoSize = true;
            this.lblawa.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblawa.Location = new System.Drawing.Point(389, 39);
            this.lblawa.Name = "lblawa";
            this.lblawa.Size = new System.Drawing.Size(85, 28);
            this.lblawa.TabIndex = 13;
            this.lblawa.Text = "Agua";
            // 
            // Limonada
            // 
            this.Limonada.AutoSize = true;
            this.Limonada.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Limonada.Location = new System.Drawing.Point(620, 304);
            this.Limonada.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Limonada.Name = "Limonada";
            this.Limonada.Size = new System.Drawing.Size(92, 27);
            this.Limonada.TabIndex = 12;
            this.Limonada.Text = "$20.00";
            this.Limonada.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(596, 358);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 19);
            this.label6.TabIndex = 7;
            // 
            // Soda
            // 
            this.Soda.AutoSize = true;
            this.Soda.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Soda.Location = new System.Drawing.Point(76, 309);
            this.Soda.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Soda.Name = "Soda";
            this.Soda.Size = new System.Drawing.Size(92, 27);
            this.Soda.TabIndex = 7;
            this.Soda.Text = "$20.00";
            this.Soda.UseVisualStyleBackColor = true;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Proyecto_Topicos.Properties.Resources._3_3_;
            this.pictureBox3.Location = new System.Drawing.Point(585, 71);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(227, 221);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // Agua
            // 
            this.Agua.AutoSize = true;
            this.Agua.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Agua.Location = new System.Drawing.Point(345, 308);
            this.Agua.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Agua.Name = "Agua";
            this.Agua.Size = new System.Drawing.Size(92, 27);
            this.Agua.TabIndex = 9;
            this.Agua.Text = "$15.00";
            this.Agua.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Proyecto_Topicos.Properties.Resources._7_2_;
            this.pictureBox2.Location = new System.Drawing.Point(310, 71);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(228, 221);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 19);
            this.label3.TabIndex = 3;
            // 
            // lblsoda
            // 
            this.lblsoda.AutoSize = true;
            this.lblsoda.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsoda.Location = new System.Drawing.Point(101, 39);
            this.lblsoda.Name = "lblsoda";
            this.lblsoda.Size = new System.Drawing.Size(84, 28);
            this.lblsoda.TabIndex = 1;
            this.lblsoda.Text = "Soda";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Proyecto_Topicos.Properties.Resources._1_4_;
            this.pictureBox1.Location = new System.Drawing.Point(44, 71);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(220, 221);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackColor = System.Drawing.Color.LavenderBlush;
            this.pictureBox11.Image = global::Proyecto_Topicos.Properties.Resources.amor;
            this.pictureBox11.Location = new System.Drawing.Point(1319, 146);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(43, 56);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox11.TabIndex = 33;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.LavenderBlush;
            this.pictureBox9.Image = global::Proyecto_Topicos.Properties.Resources.hamburguesa_vegana__1_;
            this.pictureBox9.Location = new System.Drawing.Point(1256, 209);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(134, 146);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 31;
            this.pictureBox9.TabStop = false;
            // 
            // CU_Bebidas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LavenderBlush;
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.btnBorrar);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox1);
            this.Name = "CU_Bebidas";
            this.Size = new System.Drawing.Size(1500, 733);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnBorrar;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox txtTotal2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label Vegana;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox Cafe;
        private System.Windows.Forms.CheckBox Pepino;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.CheckBox Te;
        private System.Windows.Forms.CheckBox Ice;
        private System.Windows.Forms.CheckBox KidJugo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblawa;
        private System.Windows.Forms.CheckBox Limonada;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox Soda;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.CheckBox Agua;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblsoda;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.ComboBox cbcafe;
        private System.Windows.Forms.ComboBox cbte;
        private System.Windows.Forms.ComboBox cbice;
        private System.Windows.Forms.ComboBox cbjugo;
        private System.Windows.Forms.ComboBox cbpepino;
        private System.Windows.Forms.ComboBox Cblimon;
        private System.Windows.Forms.ComboBox Cbagua;
        private System.Windows.Forms.ComboBox CbSoda;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label;
    }
}
