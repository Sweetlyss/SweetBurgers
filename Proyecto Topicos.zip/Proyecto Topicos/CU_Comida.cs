﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_Topicos
{
    public partial class CU_Comida : UserControl
    {
        public CU_Comida()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {

            int Hclass = 75, Hdob = 80, Hint = 85, Hveg = 100, Hwes = 90, Hdog = 95, Aro = 60, fries = 55;

            //Calcula el precio de las hamburguesas
            double Total = 0, t;

            if (HClasica.Checked == true)
            {
                Total = Total + Hclass * Convert.ToInt32(clasica.Text);

            }

            if (HDoble.Checked == true)
            {
                Total = Total + Hdob * Convert.ToInt32(doble.Text);
            }

            if (HIntegral.Checked == true)
            {
                Total = Total + Hint * Convert.ToInt32(integral.Text);
            }

            if (Hvegan.Checked == true)
            {
                Total = Total + Hveg * Convert.ToInt32(vegan.Text);
            }

            if (HWestern.Checked == true)
            {
                Total = Total + Hwes * Convert.ToInt32(west.Text);
            }

            if (HotD.Checked == true)
            {
                Total = Total + Hdog * Convert.ToInt32(hdog.Text);
            }

            if (Aros.Checked == true)
            {
                Total = Total + Aro * Convert.ToInt32(aritos.Text);
            }

            if (Papas.Checked == true)
            {
                Total = Total + fries * Convert.ToInt32(papitas.Text);
            }

            //Calcula los ingredientes extras
            if (Tocino.Checked == true)
            {
                Total = Total + 15;
            }
            if (Champ.Checked == true)
            {
                Total = Total + 15;
            }
            if (qso.Checked == true)
            {
                Total = Total + 15;
            }
            if (Jala.Checked == true)
            {
                Total = Total + 15;
            }

            //Operaciones


            //Impresion
            txtTotal1.Text = Total.ToString("c2");
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            txtTotal1.Clear();
            Tocino.Checked = false;
            Champ.Checked = false;
            qso.Checked = false;
            Jala.Checked = false;
            HClasica.Checked = false;
            HDoble.Checked = false;
            HIntegral.Checked = false;
            HotD.Checked = false;
            HWestern.Checked = false;
            Hvegan.Checked = false;
            Aros.Checked = false;
            Papas.Checked = false;
        }

        private void groupBox5_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void HClasica_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void clasica_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void CU_Comida_Load(object sender, EventArgs e)
        {

        }
    }
}
