﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_Topicos
{
    public partial class frm_compra : Form
    {
        public frm_compra()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            clsCompracs.CreaTicket Ticket1 = new clsCompracs.CreaTicket();

            Ticket1.TextoCentro("Empresa -Ruta del sabor- "); //imprime una linea de descripcion
            Ticket1.TextoCentro("**********************************");

            Ticket1.TextoIzquierda("");
            Ticket1.TextoCentro("Factura de Venta"); //imprime una linea de descripcion
            Ticket1.TextoIzquierda("No Fac: 0120102");
            Ticket1.TextoIzquierda("Fecha: " + DateTime.Now.ToShortDateString() + " Hora: " + DateTime.Now.ToShortTimeString());
            Ticket1.TextoIzquierda("Le Atendio: xxxx");
            Ticket1.TextoIzquierda("");
            clsCompracs.CreaTicket.LineasGuion();

            clsCompracs.CreaTicket.EncabezadoVenta();
            clsCompracs.CreaTicket.LineasGuion();
            foreach (DataGridViewRow r in dgvLista.Rows)
            {
                // PROD                     //PrECIO                                    CANT                         TOTAL
                Ticket1.AgregaArticulo(r.Cells[1].Value.ToString(), double.Parse(r.Cells[2].Value.ToString()), int.Parse(r.Cells[3].Value.ToString()), double.Parse(r.Cells[4].Value.ToString())); //imprime una linea de descripcion
            }


            clsCompracs.CreaTicket.LineasGuion();
            Ticket1.TextoIzquierda(" ");
            Ticket1.AgregaTotales("Total", double.Parse(lblTotalPagar.Text)); // imprime linea con total
            Ticket1.TextoIzquierda(" ");
            Ticket1.AgregaTotales("Efectivo Entregado:", double.Parse(txtEfectivo.Text));
            Ticket1.AgregaTotales("Efectivo Devuelto:", double.Parse(lblDevolucion.Text));


            // Ticket1.LineasTotales(); // imprime linea 

            Ticket1.TextoIzquierda(" ");
            Ticket1.TextoCentro("**********************************");
            Ticket1.TextoCentro("*     Gracias por preferirnos    *");

            Ticket1.TextoCentro("**********************************");
            Ticket1.TextoIzquierda(" ");
            string impresora = "Microsoft XPS Document Writer";
            Ticket1.ImprimirTiket(impresora);

            MessageBox.Show("Gracias por preferirnos");

            this.Close();
        }

        private void cmbProducto_SelectedIndexChanged(object sender, EventArgs e)
        {
            int cod;
            string nom;
            float precio;

            cod = cmbProducto.SelectedIndex;
            nom = cmbProducto.SelectedItem.ToString();
            precio = cmbProducto.SelectedIndex;

            switch (cod)
            {
                case 0: lblCodigo.Text = "1001"; break;
                case 1: lblCodigo.Text = "1002"; break;
                case 2: lblCodigo.Text = "1003"; break;
                case 3: lblCodigo.Text = "1004"; break;
                case 4: lblCodigo.Text = "1005"; break;
                case 5: lblCodigo.Text = "1006"; break;
                case 6: lblCodigo.Text = "1007"; break;
                case 7: lblCodigo.Text = "1008"; break;
                case 8: lblCodigo.Text = "1009"; break;
                case 9: lblCodigo.Text = "1010"; break;
                case 10: lblCodigo.Text = "1011"; break;
                case 11: lblCodigo.Text = "1012"; break;
                case 12: lblCodigo.Text = "1013"; break;
                case 13: lblCodigo.Text = "1014"; break;
                case 14: lblCodigo.Text = "1015"; break;
                case 15: lblCodigo.Text = "1016"; break;
                case 16: lblCodigo.Text = "1017"; break;
                case 17: lblCodigo.Text = "1018"; break;
                case 18: lblCodigo.Text = "1019"; break;
                case 19: lblCodigo.Text = "1020"; break;
                case 20: lblCodigo.Text = "1021"; break;
                case 21: lblCodigo.Text = "1022"; break;
                case 22: lblCodigo.Text = "1023"; break;
                case 23: lblCodigo.Text = "1024"; break;
                case 24: lblCodigo.Text = "1025"; break;
                case 25: lblCodigo.Text = "1026"; break;
                default: lblCodigo.Text = "1027"; break;
            }

            switch (nom)
            {
                case "Clasica": lblNombre.Text = "Clasica"; break;
                case "Doble": lblNombre.Text = "Doble"; break;
                case "Integral": lblNombre.Text = "Integral"; break;
                case "Western": lblNombre.Text = "Western"; break;
                case "Hot Dog": lblNombre.Text = "Hot dog"; break;
                case "Aros": lblNombre.Text = "Orden de aros"; break;
                case "Papas": lblNombre.Text = "Orden de papas"; break;
                case "Cb clasico": lblNombre.Text = "Combo clasico"; break;
                case "Cb doble": lblNombre.Text = "Combo doble carne"; break;
                case "Cbfit": lblNombre.Text = "Combo integral"; break;
                case "Pollitos": lblNombre.Text = "Combo Pollitos"; break;
                case "Hot cb": lblNombre.Text = "Hot combo"; break;
                case "Cb Vegano": lblNombre.Text = "Vegano"; break;
                case "Coca": lblNombre.Text = "Coca Cola"; break;
                case "Agua": lblNombre.Text = "Agua"; break;
                case "Limonada": lblNombre.Text = "Limonada"; break;
                case "Apepino": lblNombre.Text = "Agua de pepino"; break;
                case "Juguito": lblNombre.Text = "Juguito"; break;
                case "Ice": lblNombre.Text = "Ice"; break;
                case "Te": lblNombre.Text = "Te helado"; break;
                case "Cafe": lblNombre.Text = "Cafe"; break;
                case "Tocino": lblNombre.Text = "Tocino"; break;
                case "Champ": lblNombre.Text = "Champiñones"; break;
                case "Queso": lblNombre.Text = "Queso"; break;
                default: lblNombre.Text = "Jalap"; break;
            }

            switch (precio)
            {
                case 0: lblPrecio.Text = "75"; break;
                case 1: lblPrecio.Text = "80"; break;
                case 2: lblPrecio.Text = "85"; break;
                case 3: lblPrecio.Text = "100"; break;
                case 4: lblPrecio.Text = "95"; break;
                case 5: lblPrecio.Text = "60"; break;
                case 6: lblPrecio.Text = "55"; break;
                case 7: lblPrecio.Text = "120"; break;
                case 8: lblPrecio.Text = "125"; break;
                case 9: lblPrecio.Text = "120"; break;
                case 10: lblPrecio.Text = "170"; break;
                case 11: lblPrecio.Text = "115"; break;
                case 12: lblPrecio.Text = "95"; break;
                case 13: lblPrecio.Text = "120"; break;
                case 14: lblPrecio.Text = "150"; break;
                case 15: lblPrecio.Text = "20"; break;
                case 16: lblPrecio.Text = "15"; break;
                case 17: lblPrecio.Text = "20"; break;
                case 18: lblPrecio.Text = "20"; break;
                case 19: lblPrecio.Text = "15"; break;
                case 20: lblPrecio.Text = "35"; break;
                case 21: lblPrecio.Text = "25"; break;
                case 22: lblPrecio.Text = "45"; break;
                case 23: lblPrecio.Text = "15"; break;
                case 24: lblPrecio.Text = "15"; break;
                case 25: lblPrecio.Text = "15"; break;
                default: lblPrecio.Text = "15"; break;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DataGridViewRow file = new DataGridViewRow();
            file.CreateCells(dgvLista);

            file.Cells[0].Value = lblCodigo.Text;
            file.Cells[1].Value = lblNombre.Text;
            file.Cells[2].Value = lblPrecio.Text;
            file.Cells[3].Value = txtCantidad.Text;
            file.Cells[4].Value = (float.Parse(lblPrecio.Text) * float.Parse(txtCantidad.Text)).ToString();

            dgvLista.Rows.Add(file);

            lblCodigo.Text = lblNombre.Text = lblPrecio.Text = txtCantidad.Text = "";

            obtenerTotal();
        }

        public void obtenerTotal()
        {
            float costot = 0;
            int contador = 0;

            contador = dgvLista.RowCount;

            for (int i = 0; i < contador; i++)
            {
                costot += float.Parse(dgvLista.Rows[i].Cells[4].Value.ToString());
            }

            lblTotalPagar.Text = costot.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult rppta = MessageBox.Show("¿Desea eliminar producto?",
                    "Eliminacion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (rppta == DialogResult.Yes)
                {
                    dgvLista.Rows.Remove(dgvLista.CurrentRow);
                }
            }
            catch { }
            obtenerTotal();
        }

        private void txtEfectivo_TextChanged(object sender, EventArgs e)
        {
            
                try
                {
                    lblDevolucion.Text = (float.Parse(txtEfectivo.Text) - float.Parse(lblTotalPagar.Text)).ToString();


                }
                catch { }

                if (txtEfectivo.Text == "")
                {
                    lblDevolucion.Text = "";
                }

            
        }

        private void dgvLista_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

