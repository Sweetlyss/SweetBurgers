﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_Topicos
{
    public partial class CU_Bebidas : UserControl
    {
        public CU_Bebidas()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Calcula el precio de las hamburguesas
            double Total = 0, t;

            if (Soda.Checked == true)
            {
                Total = Total + 20 * Convert.ToInt32(CbSoda.Text);
            }

            if (Agua.Checked == true)
            {
                Total = Total + 15 * Convert.ToInt32(Cbagua.Text);
            }

            if (Limonada.Checked == true)
            {
                Total = Total + 20 * Convert.ToInt32(Cblimon.Text);
            }

            if (Pepino.Checked == true)
            {
                Total = Total + 20 * Convert.ToInt32(cbpepino.Text);
            }

            if (KidJugo.Checked == true)
            {
                Total = Total + 15 * Convert.ToInt32(cbjugo.Text);
            }

            if (Te.Checked == true)
            {
                Total = Total + 25 * Convert.ToInt32(cbte.Text);
            }

            if (Ice.Checked == true)
            {
                Total = Total + 35 * Convert.ToInt32(cbice.Text);
            }

            if (Cafe.Checked == true)
            {
                Total = Total + 45 * Convert.ToInt32(cbcafe.Text);
            }



            //Impresion
            txtTotal2.Text = Total.ToString("c2");
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            txtTotal2.Clear();
            Soda.Checked = false;
            Agua.Checked = false;
            Limonada.Checked = false;
            Pepino.Checked = false;
            KidJugo.Checked = false;
            Ice.Checked = false;
            Te.Checked = false;
            Cafe.Checked = false;
        }

        private void CbSoda_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cbte_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cbice_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cbjugo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cbpepino_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Cblimon_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Cbagua_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cbcafe_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
