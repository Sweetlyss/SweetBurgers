﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_Topicos
{
    public partial class frmMenu : Form
    {
        double Subtotal = 0;
        frm_compra compra = new frm_compra();

        public frmMenu()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            


        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            


        }

        private void button4_Click(object sender, EventArgs e)
        {
            cU_combo1.BringToFront();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cU_Comida1.BringToFront();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            cU_Bebidas1.BringToFront();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            compra.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
              frm_Datos datos = new frm_Datos();
            datos.Show();
        }

        private void cU_combo1_Load(object sender, EventArgs e)
        {

        }
    }
}
