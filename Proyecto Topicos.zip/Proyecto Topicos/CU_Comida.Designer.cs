﻿namespace Proyecto_Topicos
{
    partial class CU_Comida
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.Jala = new System.Windows.Forms.CheckBox();
            this.qso = new System.Windows.Forms.CheckBox();
            this.Champ = new System.Windows.Forms.CheckBox();
            this.Tocino = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.aritos = new System.Windows.Forms.ComboBox();
            this.papitas = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.hdog = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.west = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.vegan = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.integral = new System.Windows.Forms.ComboBox();
            this.Vegana = new System.Windows.Forms.Label();
            this.doble = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.clasica = new System.Windows.Forms.ComboBox();
            this.Papas = new System.Windows.Forms.CheckBox();
            this.Hvegan = new System.Windows.Forms.CheckBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.Aros = new System.Windows.Forms.CheckBox();
            this.HotD = new System.Windows.Forms.CheckBox();
            this.HWestern = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.HIntegral = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.HClasica = new System.Windows.Forms.CheckBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.HDoble = new System.Windows.Forms.CheckBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTotal1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnBorrar = new System.Windows.Forms.Button();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.LavenderBlush;
            this.groupBox4.Controls.Add(this.Jala);
            this.groupBox4.Controls.Add(this.qso);
            this.groupBox4.Controls.Add(this.Champ);
            this.groupBox4.Controls.Add(this.Tocino);
            this.groupBox4.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(1150, 25);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox4.Size = new System.Drawing.Size(308, 327);
            this.groupBox4.TabIndex = 23;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Extras";
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // Jala
            // 
            this.Jala.AutoSize = true;
            this.Jala.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Jala.Location = new System.Drawing.Point(20, 262);
            this.Jala.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Jala.Name = "Jala";
            this.Jala.Size = new System.Drawing.Size(197, 31);
            this.Jala.TabIndex = 3;
            this.Jala.Text = "Jalapeños $15";
            this.Jala.UseVisualStyleBackColor = true;
            // 
            // qso
            // 
            this.qso.AutoSize = true;
            this.qso.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qso.Location = new System.Drawing.Point(20, 189);
            this.qso.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.qso.Name = "qso";
            this.qso.Size = new System.Drawing.Size(152, 31);
            this.qso.TabIndex = 2;
            this.qso.Text = "Queso $15";
            this.qso.UseVisualStyleBackColor = true;
            // 
            // Champ
            // 
            this.Champ.AutoSize = true;
            this.Champ.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Champ.Location = new System.Drawing.Point(20, 123);
            this.Champ.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Champ.Name = "Champ";
            this.Champ.Size = new System.Drawing.Size(239, 31);
            this.Champ.TabIndex = 1;
            this.Champ.Text = "Champiñones $15";
            this.Champ.UseVisualStyleBackColor = true;
            // 
            // Tocino
            // 
            this.Tocino.AutoSize = true;
            this.Tocino.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tocino.Location = new System.Drawing.Point(20, 52);
            this.Tocino.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Tocino.Name = "Tocino";
            this.Tocino.Size = new System.Drawing.Size(155, 31);
            this.Tocino.TabIndex = 0;
            this.Tocino.Text = "Tocino $15";
            this.Tocino.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.LavenderBlush;
            this.groupBox1.Controls.Add(this.aritos);
            this.groupBox1.Controls.Add(this.papitas);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.hdog);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.west);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.vegan);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.integral);
            this.groupBox1.Controls.Add(this.Vegana);
            this.groupBox1.Controls.Add(this.doble);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.clasica);
            this.groupBox1.Controls.Add(this.Papas);
            this.groupBox1.Controls.Add(this.Hvegan);
            this.groupBox1.Controls.Add(this.pictureBox8);
            this.groupBox1.Controls.Add(this.pictureBox7);
            this.groupBox1.Controls.Add(this.pictureBox6);
            this.groupBox1.Controls.Add(this.pictureBox5);
            this.groupBox1.Controls.Add(this.pictureBox4);
            this.groupBox1.Controls.Add(this.Aros);
            this.groupBox1.Controls.Add(this.HotD);
            this.groupBox1.Controls.Add(this.HWestern);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.HIntegral);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.HClasica);
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.HDoble);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(21, 20);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Size = new System.Drawing.Size(1102, 674);
            this.groupBox1.TabIndex = 22;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Comida";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // aritos
            // 
            this.aritos.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aritos.FormattingEnabled = true;
            this.aritos.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.aritos.Location = new System.Drawing.Point(718, 624);
            this.aritos.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.aritos.Name = "aritos";
            this.aritos.Size = new System.Drawing.Size(57, 31);
            this.aritos.TabIndex = 47;
            // 
            // papitas
            // 
            this.papitas.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.papitas.FormattingEnabled = true;
            this.papitas.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.papitas.Location = new System.Drawing.Point(991, 620);
            this.papitas.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.papitas.Name = "papitas";
            this.papitas.Size = new System.Drawing.Size(57, 31);
            this.papitas.TabIndex = 46;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(848, 367);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(237, 28);
            this.label11.TabIndex = 30;
            this.label11.Text = "ORDEN DE PAPAS";
            // 
            // hdog
            // 
            this.hdog.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hdog.FormattingEnabled = true;
            this.hdog.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.hdog.Location = new System.Drawing.Point(458, 626);
            this.hdog.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.hdog.Name = "hdog";
            this.hdog.Size = new System.Drawing.Size(57, 31);
            this.hdog.TabIndex = 45;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Proyecto_Topicos.Properties.Resources._3_2_;
            this.pictureBox1.Location = new System.Drawing.Point(43, 73);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(220, 215);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(603, 369);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(224, 28);
            this.label10.TabIndex = 29;
            this.label10.Text = "ORDEN DE AROS";
            // 
            // west
            // 
            this.west.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.west.FormattingEnabled = true;
            this.west.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.west.Location = new System.Drawing.Point(178, 615);
            this.west.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.west.Name = "west";
            this.west.Size = new System.Drawing.Size(57, 31);
            this.west.TabIndex = 44;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(371, 367);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(131, 28);
            this.label9.TabIndex = 28;
            this.label9.Text = "HOT DOG";
            // 
            // vegan
            // 
            this.vegan.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vegan.FormattingEnabled = true;
            this.vegan.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.vegan.Location = new System.Drawing.Point(990, 295);
            this.vegan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.vegan.Name = "vegan";
            this.vegan.Size = new System.Drawing.Size(57, 31);
            this.vegan.TabIndex = 43;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(82, 367);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(138, 28);
            this.label8.TabIndex = 27;
            this.label8.Text = "WESTERN";
            // 
            // integral
            // 
            this.integral.FormattingEnabled = true;
            this.integral.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.integral.Location = new System.Drawing.Point(724, 303);
            this.integral.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.integral.Name = "integral";
            this.integral.Size = new System.Drawing.Size(57, 27);
            this.integral.TabIndex = 42;
            // 
            // Vegana
            // 
            this.Vegana.AutoSize = true;
            this.Vegana.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Vegana.Location = new System.Drawing.Point(900, 41);
            this.Vegana.Name = "Vegana";
            this.Vegana.Size = new System.Drawing.Size(119, 28);
            this.Vegana.TabIndex = 26;
            this.Vegana.Text = "VEGANA";
            // 
            // doble
            // 
            this.doble.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.doble.FormattingEnabled = true;
            this.doble.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.doble.Location = new System.Drawing.Point(458, 299);
            this.doble.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.doble.Name = "doble";
            this.doble.Size = new System.Drawing.Size(57, 31);
            this.doble.TabIndex = 41;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(639, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 28);
            this.label1.TabIndex = 25;
            this.label1.Text = "INTEGRAL";
            // 
            // clasica
            // 
            this.clasica.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clasica.FormattingEnabled = true;
            this.clasica.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.clasica.Location = new System.Drawing.Point(178, 295);
            this.clasica.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.clasica.Name = "clasica";
            this.clasica.Size = new System.Drawing.Size(57, 31);
            this.clasica.TabIndex = 40;
            this.clasica.SelectedIndexChanged += new System.EventHandler(this.clasica_SelectedIndexChanged);
            // 
            // Papas
            // 
            this.Papas.AutoSize = true;
            this.Papas.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Papas.Location = new System.Drawing.Point(893, 622);
            this.Papas.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Papas.Name = "Papas";
            this.Papas.Size = new System.Drawing.Size(92, 27);
            this.Papas.TabIndex = 24;
            this.Papas.Text = "$55.00";
            this.Papas.UseVisualStyleBackColor = true;
            // 
            // Hvegan
            // 
            this.Hvegan.AutoSize = true;
            this.Hvegan.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Hvegan.Location = new System.Drawing.Point(881, 299);
            this.Hvegan.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Hvegan.Name = "Hvegan";
            this.Hvegan.Size = new System.Drawing.Size(103, 27);
            this.Hvegan.TabIndex = 23;
            this.Hvegan.Text = "$100.00";
            this.Hvegan.UseVisualStyleBackColor = true;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::Proyecto_Topicos.Properties.Resources._8_1_;
            this.pictureBox8.Location = new System.Drawing.Point(606, 403);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(212, 215);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 22;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Proyecto_Topicos.Properties.Resources._6_1_;
            this.pictureBox7.Location = new System.Drawing.Point(326, 403);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(223, 215);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 21;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Proyecto_Topicos.Properties.Resources._1_3_;
            this.pictureBox6.Location = new System.Drawing.Point(43, 400);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(225, 213);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 20;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Proyecto_Topicos.Properties.Resources._7_1_;
            this.pictureBox5.Location = new System.Drawing.Point(853, 400);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(212, 215);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 19;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Proyecto_Topicos.Properties.Resources._4_2_;
            this.pictureBox4.Location = new System.Drawing.Point(853, 73);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(212, 215);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 18;
            this.pictureBox4.TabStop = false;
            // 
            // Aros
            // 
            this.Aros.AutoSize = true;
            this.Aros.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Aros.Location = new System.Drawing.Point(630, 624);
            this.Aros.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Aros.Name = "Aros";
            this.Aros.Size = new System.Drawing.Size(92, 27);
            this.Aros.TabIndex = 17;
            this.Aros.Text = "$60.00";
            this.Aros.UseVisualStyleBackColor = true;
            // 
            // HotD
            // 
            this.HotD.AutoSize = true;
            this.HotD.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HotD.Location = new System.Drawing.Point(350, 626);
            this.HotD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.HotD.Name = "HotD";
            this.HotD.Size = new System.Drawing.Size(92, 27);
            this.HotD.TabIndex = 16;
            this.HotD.Text = "$95.00";
            this.HotD.UseVisualStyleBackColor = true;
            // 
            // HWestern
            // 
            this.HWestern.AutoSize = true;
            this.HWestern.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HWestern.Location = new System.Drawing.Point(80, 619);
            this.HWestern.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.HWestern.Name = "HWestern";
            this.HWestern.Size = new System.Drawing.Size(92, 27);
            this.HWestern.TabIndex = 15;
            this.HWestern.Text = "$90.00";
            this.HWestern.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Baron Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(588, 194);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 20);
            this.label7.TabIndex = 14;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(328, 41);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(199, 28);
            this.label4.TabIndex = 13;
            this.label4.Text = "Carne doble";
            // 
            // HIntegral
            // 
            this.HIntegral.AutoSize = true;
            this.HIntegral.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HIntegral.Location = new System.Drawing.Point(626, 305);
            this.HIntegral.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.HIntegral.Name = "HIntegral";
            this.HIntegral.Size = new System.Drawing.Size(92, 27);
            this.HIntegral.TabIndex = 12;
            this.HIntegral.Text = "$85.00";
            this.HIntegral.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(696, 582);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 19);
            this.label6.TabIndex = 7;
            // 
            // HClasica
            // 
            this.HClasica.AutoSize = true;
            this.HClasica.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HClasica.Location = new System.Drawing.Point(80, 301);
            this.HClasica.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.HClasica.Name = "HClasica";
            this.HClasica.Size = new System.Drawing.Size(92, 27);
            this.HClasica.TabIndex = 7;
            this.HClasica.Text = "$75.00";
            this.HClasica.UseVisualStyleBackColor = true;
            this.HClasica.CheckedChanged += new System.EventHandler(this.HClasica_CheckedChanged);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Proyecto_Topicos.Properties.Resources._2_3_;
            this.pictureBox3.Location = new System.Drawing.Point(594, 73);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(212, 215);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // HDoble
            // 
            this.HDoble.AutoSize = true;
            this.HDoble.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HDoble.Location = new System.Drawing.Point(350, 301);
            this.HDoble.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.HDoble.Name = "HDoble";
            this.HDoble.Size = new System.Drawing.Size(92, 27);
            this.HDoble.TabIndex = 9;
            this.HDoble.Text = "$80.00";
            this.HDoble.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Proyecto_Topicos.Properties.Resources._5_2_;
            this.pictureBox2.Location = new System.Drawing.Point(314, 73);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(223, 215);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 19);
            this.label3.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(96, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 28);
            this.label2.TabIndex = 1;
            this.label2.Text = "Clasica";
            // 
            // txtTotal1
            // 
            this.txtTotal1.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotal1.Location = new System.Drawing.Point(73, 47);
            this.txtTotal1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTotal1.Name = "txtTotal1";
            this.txtTotal1.Size = new System.Drawing.Size(130, 36);
            this.txtTotal1.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(42, 50);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(25, 27);
            this.label5.TabIndex = 1;
            this.label5.Text = "$";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(209, 50);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(66, 27);
            this.label12.TabIndex = 2;
            this.label12.Text = "MXN";
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.LavenderBlush;
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.txtTotal1);
            this.groupBox5.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(1150, 387);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox5.Size = new System.Drawing.Size(308, 108);
            this.groupBox5.TabIndex = 21;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Total";
            this.groupBox5.Enter += new System.EventHandler(this.groupBox5_Enter);
            // 
            // btnBorrar
            // 
            this.btnBorrar.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBorrar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBorrar.Location = new System.Drawing.Point(1160, 591);
            this.btnBorrar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnBorrar.Name = "btnBorrar";
            this.btnBorrar.Size = new System.Drawing.Size(281, 58);
            this.btnBorrar.TabIndex = 25;
            this.btnBorrar.Text = "Borrar";
            this.btnBorrar.UseVisualStyleBackColor = false;
            this.btnBorrar.Click += new System.EventHandler(this.btnBorrar_Click);
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnCalcular.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(1159, 514);
            this.btnCalcular.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(282, 55);
            this.btnCalcular.TabIndex = 24;
            this.btnCalcular.Text = "Calcular orden";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // CU_Comida
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LavenderBlush;
            this.Controls.Add(this.btnBorrar);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "CU_Comida";
            this.Size = new System.Drawing.Size(1494, 746);
            this.Load += new System.EventHandler(this.CU_Comida_Load);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.CheckBox Jala;
        private System.Windows.Forms.CheckBox qso;
        private System.Windows.Forms.CheckBox Champ;
        private System.Windows.Forms.CheckBox Tocino;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label Vegana;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox Papas;
        private System.Windows.Forms.CheckBox Hvegan;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.CheckBox Aros;
        private System.Windows.Forms.CheckBox HotD;
        private System.Windows.Forms.CheckBox HWestern;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox HIntegral;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox HClasica;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.CheckBox HDoble;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ComboBox aritos;
        private System.Windows.Forms.ComboBox papitas;
        private System.Windows.Forms.ComboBox hdog;
        private System.Windows.Forms.ComboBox west;
        private System.Windows.Forms.ComboBox vegan;
        private System.Windows.Forms.ComboBox integral;
        private System.Windows.Forms.ComboBox doble;
        private System.Windows.Forms.ComboBox clasica;
        private System.Windows.Forms.TextBox txtTotal1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnBorrar;
        private System.Windows.Forms.Button btnCalcular;
    }
}
