﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Proyecto_Topicos
{
    
    public partial class frm_Datos : Form
    {

        SqlConnection conn = new SqlConnection("Data Source=SWEETLY; Initial Catalog=Menu; Integrated Security=True");

        public frm_Datos()
        {
            InitializeComponent();
            filldgv();

        }

        //Conexion a la base de datos
        //SqlConnection Conexion = new SqlConnection();

        void Limpiar()
        {
            txtID.Text = "";
            txtNombre.Text = "";
            txtApellido.Text = "";
            txtTelefono.Text = "";
            txtDireccion.Text = "";
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void frm_Datos_Load(object sender, EventArgs e)
        {

        }

        private void dgvClientes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void filldgv()
        {
            var select = "SELECT * FROM Cliente";
            var c = new SqlConnection("Data Source = SWEETLY; Initial Catalog = Menu; Integrated Security = True"); 
            var dataAdapter = new SqlDataAdapter(select, c);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            dgvClientes.ReadOnly = true;
            dgvClientes.DataSource = ds.Tables[0];
        }
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                string statement = "SELECT COUNT(*) FROM Cliente";
                int count = 0;
                using (cmd)

                {
                    using (SqlCommand cmd2 = new SqlCommand(statement, conn))
                    {
                        count = (int)cmd2.ExecuteScalar();
                    }
                }
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "INSERT INTO Cliente (ID, Nombre, Apellido, Telefono, Direccion" +
                    ") VALUES (@ID, @Nombre, @Apellido, @Telefono, @Direccion)";
                cmd.Parameters.AddWithValue("@ID", count + 1);
                cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text);
                cmd.Parameters.AddWithValue("@Apellido", txtApellido.Text);
                cmd.Parameters.AddWithValue("@Telefono", txtTelefono.Text);
                cmd.Parameters.AddWithValue("@Direccion", txtDireccion.Text);
                cmd.ExecuteNonQuery();
                conn.Close();
                bool dupe = RemoveDuplicates();
                if (dupe == true)
                {
                    MessageBox.Show("Cliente already exists");
                }
                else
                {
                    MessageBox.Show("Cliente added");
                    filldgv();
                }
            }
        }
            public bool RemoveDuplicates()
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "DELETE FROM Cliente WHERE ID NOT IN (SELECT MIN(ID) FROM Cliente GROUP BY Nombre)";
                if (cmd.ExecuteNonQuery() > 0)
                {
                    conn.Close();
                    return true;
                }
                else
                {
                    conn.Close();
                    return false;
                }
            }


            //Abre la conexion a la base de datos 
            //Conexion.Open();
            //SqlCommand Altas = new SqlCommand("INSERT INTO Clientes (IDCliente, Nombre, Apellido, Telefono, Direccion) VALUES (@IDCliente, @Nombre, @Apellido, @Telefono, @Direccion)", Conexion);
            //Altas.Parameters.AddWithValue("IDCliente", txtID.Text);
            //Altas.Parameters.AddWithValue("Nombre", txtNombre.Text);
            //Altas.Parameters.AddWithValue("Apellido", txtApellido.Text);
            //Altas.Parameters.AddWithValue("Telefono", txtTelefono.Text);
            //Altas.Parameters.AddWithValue("Direccion", txtDireccion.Text);
            //Altas.ExecuteNonQuery();
            //MostrarDB();
            //Limpiar();
            //MessageBox.Show("USUARIO DADO DE ALTA");
            //Conexion.Close();
        

        private void btnModificar_Click(object sender, EventArgs e)
        {
            //Conexion.Open();
            //SqlCommand actualizar = new SqlCommand("UPDATE Clientes SET IDCliente=@IDCliente, Nombre=@Nombre, Apellido=@Apellido, Telefono=@Telefono, Direccion=@Direccion WHERE IDCliente=@IDCliente", Conexion);
            //actualizar.Parameters.AddWithValue("IDCliente", txtID.Text);
            //actualizar.Parameters.AddWithValue("Nombre", txtNombre.Text);
            //actualizar.Parameters.AddWithValue("Apellido", txtApellido.Text);
            //actualizar.Parameters.AddWithValue("Telefono", txtTelefono.Text);
            //actualizar.Parameters.AddWithValue("Direccion", txtDireccion.Text);
            //actualizar.ExecuteNonQuery();
            //MessageBox.Show("MODIFICACION REALIZADA");
            //MostrarDB();
            //Conexion.Close();
            //foreach (Control ctrl in this.Controls)
            //{
            //    if (ctrl is TextBox)
            //    {
            //        TextBox text = ctrl as TextBox;
            //        text.Clear();
            //    }
            //}
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            //Conexion.Open();
            //string Eliminar = "DELETE FROM Clientes WHERE IDCliente=@IDCliente";
            //SqlCommand cmdbj = new SqlCommand(Eliminar, Conexion);
            //cmdbj.Parameters.AddWithValue("IDCliente", txtID.Text);
            //cmdbj.ExecuteNonQuery();
            //cmdbj.Dispose();
            //cmdbj = null;
            //MostrarDB();
            //Limpiar();
            //Conexion.Close();
            MessageBox.Show("USUARIO ELIMINADO");
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            //SqlCommand consulta = new SqlCommand("SELECT * FROM Clientes WHERE Telefono=@Telefono", Conexion);
            //Conexion.Open();
            //consulta.Parameters.AddWithValue("Telefono", txtBuscar.Text);
            //SqlDataReader reader = consulta.ExecuteReader();
            //while (reader.Read())
            //{
            //    txtID.Text = reader[0].ToString();
            //    txtNombre.Text = reader[1].ToString();
            //    txtApellido.Text = reader[2].ToString();
            //    txtTelefono.Text = reader[3].ToString();
            //    txtDireccion.Text = reader[4].ToString();
            //}
            MessageBox.Show("SE REALIZO LA CONSULTA");
            //Conexion.Close();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtDireccion_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void txtTelefono_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnSalir_Click_1(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
