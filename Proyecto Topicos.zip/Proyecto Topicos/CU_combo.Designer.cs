﻿namespace Proyecto_Topicos
{
    partial class CU_combo
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.cbvegan = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cbdog = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cbpollito = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cbwst = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cbcompas = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Cbinteg = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Cbdoble = new System.Windows.Forms.ComboBox();
            this.Cbclass = new System.Windows.Forms.ComboBox();
            this.Vegan = new System.Windows.Forms.CheckBox();
            this.Compas = new System.Windows.Forms.CheckBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.Hot = new System.Windows.Forms.CheckBox();
            this.Pollitos = new System.Windows.Forms.CheckBox();
            this.Western = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Integral = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Clasico = new System.Windows.Forms.CheckBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.Doble = new System.Windows.Forms.CheckBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.Jala = new System.Windows.Forms.CheckBox();
            this.qso = new System.Windows.Forms.CheckBox();
            this.Cham = new System.Windows.Forms.CheckBox();
            this.Tocino = new System.Windows.Forms.CheckBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.btnBorrar = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.cbvegan);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.cbdog);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.cbpollito);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.cbwst);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.cbcompas);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.Cbinteg);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.Cbdoble);
            this.groupBox1.Controls.Add(this.Cbclass);
            this.groupBox1.Controls.Add(this.Vegan);
            this.groupBox1.Controls.Add(this.Compas);
            this.groupBox1.Controls.Add(this.pictureBox8);
            this.groupBox1.Controls.Add(this.pictureBox7);
            this.groupBox1.Controls.Add(this.pictureBox6);
            this.groupBox1.Controls.Add(this.pictureBox5);
            this.groupBox1.Controls.Add(this.pictureBox4);
            this.groupBox1.Controls.Add(this.Hot);
            this.groupBox1.Controls.Add(this.Pollitos);
            this.groupBox1.Controls.Add(this.Western);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.Integral);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.Clasico);
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.Doble);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(22, 23);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Size = new System.Drawing.Size(1091, 679);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Combo";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Baron Neue", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(566, 167);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(0, 20);
            this.label14.TabIndex = 50;
            // 
            // cbvegan
            // 
            this.cbvegan.FormattingEnabled = true;
            this.cbvegan.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.cbvegan.Location = new System.Drawing.Point(974, 607);
            this.cbvegan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbvegan.Name = "cbvegan";
            this.cbvegan.Size = new System.Drawing.Size(57, 27);
            this.cbvegan.TabIndex = 46;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(908, 339);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(103, 28);
            this.label11.TabIndex = 30;
            this.label11.Text = "VEGAN";
            // 
            // cbdog
            // 
            this.cbdog.FormattingEnabled = true;
            this.cbdog.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.cbdog.Location = new System.Drawing.Point(706, 607);
            this.cbdog.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbdog.Name = "cbdog";
            this.cbdog.Size = new System.Drawing.Size(57, 27);
            this.cbdog.TabIndex = 45;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(608, 341);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(170, 28);
            this.label10.TabIndex = 29;
            this.label10.Text = "HOT COMBO";
            // 
            // cbpollito
            // 
            this.cbpollito.FormattingEnabled = true;
            this.cbpollito.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.cbpollito.Location = new System.Drawing.Point(442, 607);
            this.cbpollito.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbpollito.Name = "cbpollito";
            this.cbpollito.Size = new System.Drawing.Size(57, 27);
            this.cbpollito.TabIndex = 44;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(360, 341);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(130, 28);
            this.label9.TabIndex = 28;
            this.label9.Text = "POLLITOS";
            // 
            // cbwst
            // 
            this.cbwst.FormattingEnabled = true;
            this.cbwst.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.cbwst.Location = new System.Drawing.Point(161, 609);
            this.cbwst.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbwst.Name = "cbwst";
            this.cbwst.Size = new System.Drawing.Size(57, 27);
            this.cbwst.TabIndex = 43;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(80, 341);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(138, 28);
            this.label8.TabIndex = 27;
            this.label8.Text = "WESTERN";
            // 
            // cbcompas
            // 
            this.cbcompas.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbcompas.FormattingEnabled = true;
            this.cbcompas.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.cbcompas.Location = new System.Drawing.Point(974, 287);
            this.cbcompas.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbcompas.Name = "cbcompas";
            this.cbcompas.Size = new System.Drawing.Size(57, 31);
            this.cbcompas.TabIndex = 42;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(889, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(122, 28);
            this.label5.TabIndex = 26;
            this.label5.Text = "COMPAS";
            // 
            // Cbinteg
            // 
            this.Cbinteg.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cbinteg.FormattingEnabled = true;
            this.Cbinteg.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.Cbinteg.Location = new System.Drawing.Point(697, 288);
            this.Cbinteg.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Cbinteg.Name = "Cbinteg";
            this.Cbinteg.Size = new System.Drawing.Size(57, 31);
            this.Cbinteg.TabIndex = 41;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(622, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 28);
            this.label1.TabIndex = 25;
            this.label1.Text = "INTEGRAL";
            // 
            // Cbdoble
            // 
            this.Cbdoble.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cbdoble.FormattingEnabled = true;
            this.Cbdoble.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.Cbdoble.Location = new System.Drawing.Point(453, 287);
            this.Cbdoble.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Cbdoble.Name = "Cbdoble";
            this.Cbdoble.Size = new System.Drawing.Size(57, 31);
            this.Cbdoble.TabIndex = 40;
            // 
            // Cbclass
            // 
            this.Cbclass.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cbclass.FormattingEnabled = true;
            this.Cbclass.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.Cbclass.Location = new System.Drawing.Point(163, 285);
            this.Cbclass.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Cbclass.Name = "Cbclass";
            this.Cbclass.Size = new System.Drawing.Size(57, 31);
            this.Cbclass.TabIndex = 39;
            // 
            // Vegan
            // 
            this.Vegan.AutoSize = true;
            this.Vegan.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Vegan.Location = new System.Drawing.Point(865, 609);
            this.Vegan.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Vegan.Name = "Vegan";
            this.Vegan.Size = new System.Drawing.Size(103, 27);
            this.Vegan.TabIndex = 24;
            this.Vegan.Text = "$150.00";
            this.Vegan.UseVisualStyleBackColor = true;
            // 
            // Compas
            // 
            this.Compas.AutoSize = true;
            this.Compas.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Compas.Location = new System.Drawing.Point(865, 292);
            this.Compas.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Compas.Name = "Compas";
            this.Compas.Size = new System.Drawing.Size(103, 27);
            this.Compas.TabIndex = 23;
            this.Compas.Text = "$170.00";
            this.Compas.UseVisualStyleBackColor = true;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::Proyecto_Topicos.Properties.Resources._6;
            this.pictureBox8.Location = new System.Drawing.Point(572, 384);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(214, 210);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 22;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Proyecto_Topicos.Properties.Resources._7;
            this.pictureBox7.Location = new System.Drawing.Point(305, 384);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(218, 212);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 21;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Proyecto_Topicos.Properties.Resources._3;
            this.pictureBox6.Location = new System.Drawing.Point(23, 380);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(221, 214);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 20;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Proyecto_Topicos.Properties.Resources._5;
            this.pictureBox5.Location = new System.Drawing.Point(842, 382);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(212, 210);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 19;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Proyecto_Topicos.Properties.Resources._4;
            this.pictureBox4.Location = new System.Drawing.Point(830, 61);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(224, 222);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 18;
            this.pictureBox4.TabStop = false;
            // 
            // Hot
            // 
            this.Hot.AutoSize = true;
            this.Hot.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Hot.Location = new System.Drawing.Point(597, 609);
            this.Hot.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Hot.Name = "Hot";
            this.Hot.Size = new System.Drawing.Size(103, 27);
            this.Hot.TabIndex = 17;
            this.Hot.Text = "$120.00";
            this.Hot.UseVisualStyleBackColor = true;
            // 
            // Pollitos
            // 
            this.Pollitos.AutoSize = true;
            this.Pollitos.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pollitos.Location = new System.Drawing.Point(344, 607);
            this.Pollitos.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Pollitos.Name = "Pollitos";
            this.Pollitos.Size = new System.Drawing.Size(92, 27);
            this.Pollitos.TabIndex = 16;
            this.Pollitos.Text = "$95.00";
            this.Pollitos.UseVisualStyleBackColor = true;
            // 
            // Western
            // 
            this.Western.AutoSize = true;
            this.Western.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Western.Location = new System.Drawing.Point(54, 610);
            this.Western.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Western.Name = "Western";
            this.Western.Size = new System.Drawing.Size(103, 27);
            this.Western.TabIndex = 15;
            this.Western.Text = "$115.00";
            this.Western.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(522, 28);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 28);
            this.label7.TabIndex = 14;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(324, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(199, 28);
            this.label4.TabIndex = 13;
            this.label4.Text = "Carne doble";
            // 
            // Integral
            // 
            this.Integral.AutoSize = true;
            this.Integral.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Integral.Location = new System.Drawing.Point(588, 293);
            this.Integral.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Integral.Name = "Integral";
            this.Integral.Size = new System.Drawing.Size(103, 27);
            this.Integral.TabIndex = 12;
            this.Integral.Text = "$120.00";
            this.Integral.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(607, 481);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 19);
            this.label6.TabIndex = 7;
            // 
            // Clasico
            // 
            this.Clasico.AutoSize = true;
            this.Clasico.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clasico.Location = new System.Drawing.Point(54, 287);
            this.Clasico.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Clasico.Name = "Clasico";
            this.Clasico.Size = new System.Drawing.Size(103, 27);
            this.Clasico.TabIndex = 7;
            this.Clasico.Text = "$120.00";
            this.Clasico.UseVisualStyleBackColor = true;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Proyecto_Topicos.Properties.Resources._8;
            this.pictureBox3.Location = new System.Drawing.Point(570, 66);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(216, 219);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // Doble
            // 
            this.Doble.AutoSize = true;
            this.Doble.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Doble.Location = new System.Drawing.Point(344, 292);
            this.Doble.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Doble.Name = "Doble";
            this.Doble.Size = new System.Drawing.Size(103, 27);
            this.Doble.TabIndex = 9;
            this.Doble.Text = "$125.00";
            this.Doble.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Proyecto_Topicos.Properties.Resources._2;
            this.pictureBox2.Location = new System.Drawing.Point(305, 66);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(219, 215);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 19);
            this.label3.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Baron Neue", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(75, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 28);
            this.label2.TabIndex = 1;
            this.label2.Text = "Clasico";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Proyecto_Topicos.Properties.Resources._1;
            this.pictureBox1.Location = new System.Drawing.Point(23, 62);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(218, 217);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.LavenderBlush;
            this.groupBox4.Controls.Add(this.Jala);
            this.groupBox4.Controls.Add(this.qso);
            this.groupBox4.Controls.Add(this.Cham);
            this.groupBox4.Controls.Add(this.Tocino);
            this.groupBox4.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(1137, 34);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox4.Size = new System.Drawing.Size(306, 298);
            this.groupBox4.TabIndex = 18;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Extras";
            // 
            // Jala
            // 
            this.Jala.AutoSize = true;
            this.Jala.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Jala.Location = new System.Drawing.Point(21, 223);
            this.Jala.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Jala.Name = "Jala";
            this.Jala.Size = new System.Drawing.Size(197, 31);
            this.Jala.TabIndex = 3;
            this.Jala.Text = "Jalapeños $15";
            this.Jala.UseVisualStyleBackColor = true;
            // 
            // qso
            // 
            this.qso.AutoSize = true;
            this.qso.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qso.Location = new System.Drawing.Point(21, 174);
            this.qso.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.qso.Name = "qso";
            this.qso.Size = new System.Drawing.Size(152, 31);
            this.qso.TabIndex = 2;
            this.qso.Text = "Queso $15";
            this.qso.UseVisualStyleBackColor = true;
            // 
            // Cham
            // 
            this.Cham.AutoSize = true;
            this.Cham.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cham.Location = new System.Drawing.Point(18, 118);
            this.Cham.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Cham.Name = "Cham";
            this.Cham.Size = new System.Drawing.Size(239, 31);
            this.Cham.TabIndex = 1;
            this.Cham.Text = "Champiñones $15";
            this.Cham.UseVisualStyleBackColor = true;
            // 
            // Tocino
            // 
            this.Tocino.AutoSize = true;
            this.Tocino.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tocino.Location = new System.Drawing.Point(18, 55);
            this.Tocino.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Tocino.Name = "Tocino";
            this.Tocino.Size = new System.Drawing.Size(155, 31);
            this.Tocino.TabIndex = 0;
            this.Tocino.Text = "Tocino $15";
            this.Tocino.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.LavenderBlush;
            this.groupBox5.Controls.Add(this.label13);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.txtTotal);
            this.groupBox5.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(1137, 340);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox5.Size = new System.Drawing.Size(306, 126);
            this.groupBox5.TabIndex = 8;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Total";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(212, 62);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(66, 27);
            this.label13.TabIndex = 2;
            this.label13.Text = "MXN";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(39, 59);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(25, 27);
            this.label12.TabIndex = 1;
            this.label12.Text = "$";
            // 
            // txtTotal
            // 
            this.txtTotal.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotal.Location = new System.Drawing.Point(74, 56);
            this.txtTotal.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(132, 36);
            this.txtTotal.TabIndex = 0;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(1158, 491);
            this.btnCalcular.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(257, 46);
            this.btnCalcular.TabIndex = 19;
            this.btnCalcular.Text = "Calcular orden";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // btnBorrar
            // 
            this.btnBorrar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBorrar.Location = new System.Drawing.Point(1158, 545);
            this.btnBorrar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnBorrar.Name = "btnBorrar";
            this.btnBorrar.Size = new System.Drawing.Size(257, 46);
            this.btnBorrar.TabIndex = 20;
            this.btnBorrar.Text = "Borrar";
            this.btnBorrar.UseVisualStyleBackColor = true;
            this.btnBorrar.Click += new System.EventHandler(this.btnBorrar_Click);
            // 
            // CU_combo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LavenderBlush;
            this.Controls.Add(this.btnBorrar);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "CU_combo";
            this.Size = new System.Drawing.Size(1500, 733);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.CheckBox Hot;
        private System.Windows.Forms.CheckBox Pollitos;
        private System.Windows.Forms.CheckBox Western;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox Integral;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox Clasico;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.CheckBox Doble;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.CheckBox Jala;
        private System.Windows.Forms.CheckBox qso;
        private System.Windows.Forms.CheckBox Cham;
        private System.Windows.Forms.CheckBox Tocino;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Button btnBorrar;
        private System.Windows.Forms.CheckBox Vegan;
        private System.Windows.Forms.CheckBox Compas;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbvegan;
        private System.Windows.Forms.ComboBox cbdog;
        private System.Windows.Forms.ComboBox cbpollito;
        private System.Windows.Forms.ComboBox cbwst;
        private System.Windows.Forms.ComboBox cbcompas;
        private System.Windows.Forms.ComboBox Cbinteg;
        private System.Windows.Forms.ComboBox Cbdoble;
        private System.Windows.Forms.ComboBox Cbclass;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
    }
}
