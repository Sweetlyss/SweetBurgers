﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_Topicos
{
    public partial class frmIngreso : Form
    {
        public frmIngreso()
        {
            InitializeComponent();
        }

        //Boton que da acceso a los usuarios
        private void btnIngresar_Click(object sender, EventArgs e)
        {
            //Validacion de Roman y contraseña
            if (txtUsuario.Text == "Admin" && txtContraseña.Text == "1234")
            {
                frmMenu menu = new frmMenu();
                this.Hide();
                menu.Show();
            }
            else
            {
                MessageBox.Show("Los datos ingresados son erroneos", "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtUsuario.Clear();
                txtContraseña.Clear();
            }
            
        }

        //Metodo para establecer la contraseña solo con valores numericos
        private void txtContraseña_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
                MessageBox.Show("Solo se permite ingresar valores numéricos",
                "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        //Cancela los datos ingresados
        private void btnCancelar_Click(object sender, EventArgs e)
        {
            txtUsuario.Clear();
            txtContraseña.Clear();
            txtUsuario.Focus();
        }

        private void btnCrear_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
    
}
