﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_Topicos
{
    public partial class CU_combo : UserControl
    {
        public CU_combo()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Calcula el precio de las hamburguesas
            double Total = 0, t;

            if (Clasico.Checked == true)
            {
                Total = Total + 120 * Convert.ToInt32(Cbclass.Text);
            }

            if (Doble.Checked == true)
            {
                Total = Total + 125 * Convert.ToInt32(Cbdoble.Text);
            }

            if (Integral.Checked == true)
            {
                Total = Total + 120 * Convert.ToInt32(Cbinteg.Text);
            }

            if (Compas.Checked == true)
            {
                Total = Total + 170 * Convert.ToInt32(cbcompas.Text);
            }

            if (Western.Checked == true)
            {
                Total = Total + 115 * Convert.ToInt32(cbwst.Text);
            }

            if (Pollitos.Checked == true)
            {
                Total = Total + 95 * Convert.ToInt32(cbpollito.Text);
            }

            if (Hot.Checked == true)
            {
                Total = Total + 60 * Convert.ToInt32(cbdog.Text);
            }

            if (Vegan.Checked == true)
            {
                Total = Total + 55 * Convert.ToInt32(cbvegan.Text);
            }

            //Calcula los ingredientes extras
            if (Tocino.Checked == true)
            {
                Total = Total + 15;
            }
            if (Cham.Checked == true)
            {
                Total = Total + 15;
            }
            if (qso.Checked == true)
            {
                Total = Total + 15;
            }
            if (Jala.Checked == true)
            {
                Total = Total + 15;
            }

            //Operaciones


            //Impresion
            txtTotal.Text = Total.ToString("c2");
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            txtTotal.Clear();
            Tocino.Checked = false;
            Cham.Checked = false;
            qso.Checked = false;
            Jala.Checked = false;
            Clasico.Checked = false;
            Doble.Checked = false;
            Integral.Checked = false;
            Compas.Checked = false;
            Western.Checked = false;
            Pollitos.Checked = false;
            Vegan.Checked = false;
            Hot.Checked = false;

        }
    }
}
